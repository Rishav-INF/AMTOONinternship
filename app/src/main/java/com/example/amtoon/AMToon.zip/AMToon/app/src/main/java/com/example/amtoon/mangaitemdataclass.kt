data class mangaitemdataclass(
    var title: String? = null,
    var creator: String? = null,
    var episode: String? = null,
    var reads: String? = null,
    var release: String? = null,
    var imageLink: String? = null,
    var description: String? = null
)
